package smartdevelop.ir.eram.showcaseviewlib.config;

public enum PointerType {
    circle, arrow, none
}
