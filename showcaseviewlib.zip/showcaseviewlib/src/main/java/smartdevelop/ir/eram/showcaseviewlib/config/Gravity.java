package smartdevelop.ir.eram.showcaseviewlib.config;

/**
 * Created by Mohammad Reza Eram (https://github.com/mreram) on 27,November,2018
 */
public enum Gravity {
    auto, center, sideauto, sidecenter
}

